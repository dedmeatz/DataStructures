import UIKit
import Foundation

func bubbleSort(array: [Int]) -> [Int]{
    var array = array
    for index in 0..<array.count {
        for index2 in (index)..<(array.count) {
            if(array[index2] < array[index]){
                let temp = array[index2]
                array[index2] = array[index]
                array[index] = temp
            }
        }
    }
    return array
}

func selectionSort(array: [Int]) -> [Int]{
    var array = array
    for index in 1..<array.count {
        var key = array[index]
        var i2 = index-1
        while(i2 > (-1) && array[i2] > key){
            array[i2+1] = array[i2]
            i2 = i2-1
        }
        array[i2+1] = key
    }
    return array
}